import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Typography,Grid,Button,Box } from '@mui/material';
import { useState } from 'react';
import { typography } from '@mui/system';

function App() {

  const [questionIndex,setQuestionIndex] = useState(0)
  const [marks,setMarks] = useState(0)
  const [finishBtn,setFinishBtn] = useState(false)
  const [result,setResult] = useState(false)

  const questions = [
    {
      question:" Q1) HTML STANDS FOR ----------------------",
      options:['Hyper text markup language','Hyper Text','Hyper for'],
      answer:'Hyper text markup language'
    },
    {
      question:" Q2) Javscript is a ------------ language",
     options:['Programming','none of these','Java'],
      answer:'programming'
    },
    {
      question:" Q3) React is a ---------------",
      options:['Two page Application','programming','Single Page Application'],
      answer:'Single Page Application'
    },
    {
      question:" Q4) Inside which HTML element do we put the JavaScript?",
      options:['none of the above','<script>','</js>'],
      answer:'<script>'
    }
  ]

  let nextQuestion = (e) =>{
    let a = e.target.value

    if(a === questions[questionIndex].answer){
      setMarks(marks+1)
    }


    if(questions.length-1 !== questionIndex){
      setQuestionIndex(questionIndex+1)
    }else{
      setFinishBtn(!finishBtn)
    }
console.log(marks)
  }

  let showResult = () => {
    setResult(!result)
  }



   
  return (
    <div container className="head">
    
    <div>
    <Grid container>
      <Grid >

        <Grid sx={{pt:3}} >
          <Typography component="div" textalign='center' variant='h4'>
           { questions[questionIndex].question }
          </Typography>
        </Grid>
<div>
    <Box sx={{pt:3}} className="but" >

    { questions[questionIndex].options.map((option,index)=>{

      return <Button sx={{my:2,mx:2}} variant='contained' key={index} value={option} onClick={(e)=>nextQuestion(e)}  >
        {option}
        </Button>
    })}

    </Box>

    </div>

      <Box className="all">
        {finishBtn &&  <Button variant='contained' onClick={showResult}>Finish quiz</Button> }

        {result && <Box>
          <Typography>
            {marks/questions.length*100}%
            {marks}
          </Typography>
          </Box>}
      </Box>


    


      </Grid>
    </Grid>
    </div>


  </div>
  );
}

export default App;
